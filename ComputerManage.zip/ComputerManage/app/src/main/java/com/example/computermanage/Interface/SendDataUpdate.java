package com.example.computermanage.Interface;

import com.example.computermanage.model.Hang;

import java.util.ArrayList;

public interface SendDataUpdate {
    void upDate(ArrayList<Hang> listH);
}
