package com.example.computermanage.model;

public class GetSLNhap {
    int soluong;

    public GetSLNhap(int soluong) {
        this.soluong = soluong;
    }

    public GetSLNhap() {
    }

    public int getSoluong() {
        return soluong;
    }

    public void setSoluong(int soluong) {
        this.soluong = soluong;
    }

    @Override
    public String toString() {
        return String.valueOf(getSoluong());
    }
}
