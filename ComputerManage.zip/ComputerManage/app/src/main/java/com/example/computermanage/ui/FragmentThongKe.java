package com.example.computermanage.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.example.computermanage.dao.DAOHoaDon;
import com.example.computermanage.dao.DAOHoaDonCT;
import com.example.computermanage.R;
import com.example.computermanage.model.HoaDon;
import com.example.computermanage.model.HoaDonChiTiet;

import java.util.ArrayList;

public class FragmentThongKe extends Fragment {
    TextView tv_doanhthu;
    TextView tv_doanhthulai;
    TextView slnhap;
    DAOHoaDonCT daoHoaDonCT;
    DAOHoaDon daoHoaDon;
    ArrayList<HoaDon> listHDN;
    ArrayList<HoaDon> listHDX;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = LayoutInflater.from(getContext()).inflate(R.layout.fragment_thongke, container, false);
        tv_doanhthu = view.findViewById(R.id.tv_doanhthu);
        tv_doanhthulai = view.findViewById(R.id.tv_doanhthulai);
        slnhap = view.findViewById(R.id.slnhap);
        daoHoaDonCT = new DAOHoaDonCT(getContext());
        daoHoaDon = new DAOHoaDon(getContext());
        listHDN = new ArrayList<>();
        listHDX = new ArrayList<>();
        listHDN = daoHoaDon.getAllNhap();
        listHDX = daoHoaDon.getAllXuat();
        if (listHDN.size() > 0 && listHDX.size() > 0) {
            tv_doanhthu.setText("" + daoHoaDonCT.doanhthu());
            double nhap = daoHoaDonCT.thanhtiennhap();
            double xuat = daoHoaDonCT.thanhtienxuat();
            tv_doanhthulai.setText((nhap - xuat) + "");
        } else {
            tv_doanhthu.setText("0");
            tv_doanhthulai.setText("0");
        }
//        ArrayList<GetSLNhap> listNhap = daoHoaDonCT.slNhap();
//        ArrayList<GetSLXuat> getSLXuats = daoHoaDonCT.slXuat();
//        ArrayList<GetDonGiaNhap> listDGNhap = daoHoaDonCT.dgNhap();
//        for (int i = 0; i < listNhap.size(); i++) {
//           int slton =  listNhap.get(i).getSoluong()-getSLXuats.get(i).getSlxuat();
//            Log.e("TAG", "onCreateView: "+(listNhap.get(i).getSoluong()-getSLXuats.get(i).getSlxuat()) );
//        }
        return view;
    }
}
