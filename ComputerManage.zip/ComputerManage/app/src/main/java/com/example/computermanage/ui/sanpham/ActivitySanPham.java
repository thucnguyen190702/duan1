package com.example.computermanage.ui.sanpham;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.example.computermanage.adapter.AdapterSanPham;
import com.example.computermanage.dao.DAOSanPham;
import com.example.computermanage.model.SanPham;
import com.example.computermanage.R;

import java.util.ArrayList;

public class ActivitySanPham extends AppCompatActivity {
    RecyclerView rcv_SanPham;
    DAOSanPham daoSanPham;
    ArrayList<SanPham> listSP;
    AdapterSanPham adapterSanPham;
    Toolbar toolbar;
    Spinner spn_SXSanPham;
    String[] mang = new String[]{
            "Mặc định",
            "Sắp xếp theo mã",
            "Sắp xếp theo tên",
            "Sắp xếp theo giá"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_san_pham);
        addControl();
        addDataRecycleView();
    }

    private void addDataRecycleView() {
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(ActivitySanPham.this);
        rcv_SanPham.setLayoutManager(layoutManager);
        listSP = daoSanPham.getAll();
        adapterSanPham = new AdapterSanPham(ActivitySanPham.this, listSP);
        rcv_SanPham.setAdapter(adapterSanPham);
    }

    private void addControl() {

        rcv_SanPham = findViewById(R.id.rcv_SanPham);
        spn_SXSanPham = findViewById(R.id.spn_SXSanPham);
        toolbar = findViewById(R.id.tb_SP);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Sản phẩm");
        toolbar.setTitleTextColor(Color.WHITE);
        final Drawable upArrow = getResources().getDrawable(R.drawable.ic_back);
        upArrow.setColorFilter(Color.parseColor("#FFFFFF"), PorterDuff.Mode.SRC_ATOP);
        getSupportActionBar().setHomeAsUpIndicator(upArrow);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        daoSanPham = new DAOSanPham(this);
        listSP = new ArrayList<>();
        ArrayAdapter adapter = new ArrayAdapter(ActivitySanPham.this, android.R.layout.simple_list_item_1, mang);
        spn_SXSanPham.setAdapter(adapter);
        spn_SXSanPham.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case 0:
                        listSP.clear();
                        listSP.addAll(daoSanPham.getAll());
                        adapterSanPham.notifyDataSetChanged();
                        break;
                    case 1:
                        listSP.clear();
                        listSP.addAll(daoSanPham.getAllSXMa());
                        adapterSanPham.notifyDataSetChanged();
                        break;
                    case 2:
                        listSP.clear();
                        listSP.addAll(daoSanPham.getAllSXTen());
                        adapterSanPham.notifyDataSetChanged();
                        break;

                    case 3:
                        listSP.clear();
                        listSP.addAll(daoSanPham.getAllSXGia());
                        adapterSanPham.notifyDataSetChanged();
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_add, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_add:
                startActivity(new Intent(ActivitySanPham.this, ActivityAddSanPham.class));
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}