package com.example.computermanage.model;

public class GetSLXuat {
    int slxuat;

    public GetSLXuat(int slxuat) {
        this.slxuat = slxuat;
    }

    public GetSLXuat() {
    }

    public int getSlxuat() {
        return slxuat;
    }

    public void setSlxuat(int slxuat) {
        this.slxuat = slxuat;
    }

    @Override
    public String toString() {
        return String.valueOf(getSlxuat());
    }
}
