package com.example.computermanage.sql;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class CreateSQL extends SQLiteOpenHelper {
    public CreateSQL(@Nullable Context context) {
        super(context, "computermanage.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        //create table nhanvien
        String CREATE_TABLE_NHANVIEN = "CREATE TABLE nhanvien(" +
                "msnv TEXT UNIQUE PRIMARY KEY NOT NULL," +
                "password TEXT  ," +
                "hoten TEXT  ," +
                "sdt TEXT  ," +
                "email TEXT," +
                "hinhanh BLOB)";
        db.execSQL(CREATE_TABLE_NHANVIEN);
        String nhanvien=" insert into nhanvien values('Nv1','123123','Admin','1231231231','q@gmail.com',null)";
        db.execSQL(nhanvien);

        //create table khachhang
        String CREATE_TABLE_KHACHHANG = "CREATE TABLE khachhang(" +
                "mskh TEXT UNIQUE PRIMARY KEY NOT NULL," +
                "hoten TEXT  ," +
                "sdt TEXT  ," +
                "gioitinh TEXT  ," +
                "diachi TEXT  )";
        db.execSQL(CREATE_TABLE_KHACHHANG);
        String khachhang=" insert into khachhang values('Kh1','Cuong','1231231231',0,'hanoi')";
        db.execSQL(khachhang);
        //create table hang
        String CREATE_TABLE_HANG = "CREATE TABLE hang(" +
                "mshang INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL," +
                "tenhang TEXT   , hinhanh BLOB)";
        db.execSQL(CREATE_TABLE_HANG);
        String hang=" insert into hang values(1,'Hang1',null)";
        db.execSQL(hang);
        //create table loaisanpham
        String CREATE_TABLE_LOAISANPHAM = "CREATE TABLE loaisanpham(" +
                "mslsp TEXT UNIQUE PRIMARY KEY NOT NULL," +
                "mshang INTEGER NOT NULL REFERENCES hang(mshang) ON DELETE CASCADE ON UPDATE CASCADE," +
                "tenlsp TEXT  ," +
                "hinhanh BLOB)";
        db.execSQL(CREATE_TABLE_LOAISANPHAM);
        String loaisanpham=" insert into loaisanpham values('Loai1',1,'Dell',null)";
        db.execSQL(loaisanpham);
        String CREATE_TABLE_SANPHAM = "CREATE TABLE sanpham(" +
                "mssp TEXT PRIMARY KEY NOT NULL," +
                "mslsp TEXT NOT NULL REFERENCES loaisanpham(mslsp) ON DELETE CASCADE ON UPDATE CASCADE," +
                "tensp TEXT  ," +
                "giatien DECIMAL(20,0) ," +
                "tinhtrang INTEGER ," +
                "trangthai INTEGER ," +
                "hinhanh BLOB," +
                "mota TEXT)";
        db.execSQL(CREATE_TABLE_SANPHAM);
        //create table sanphamchitiet
        String sanpham=" insert into sanpham values('Sp1','Loai1','Dell Latitude',20,2,1,null,'mota')";
        db.execSQL(sanpham);

        String CREATE_TABLE_SPCHITIET = "CREATE TABLE sanphamchitiet(" +
                "msspct INTEGER PRIMARY KEY AUTOINCREMENT," +
                "mssp TEXT NOT NULL REFERENCES sanpham(mssp) ON DELETE CASCADE ON UPDATE CASCADE ," +
                "cpu TEXT," +
                "ram TEXT," +
                "ocung TEXT," +
                "hedieuhanh TEXT," +
                "manhinh TEXT," +
                "cardmh TEXT," +
                "pin TEXT," +
                "trongluong FLOAT)";
        db.execSQL(CREATE_TABLE_SPCHITIET);
        String sanphamchitiet=" insert into sanphamchitiet values(1,'Sp1','i5','4gb','sdd','android','HP','VGA','1000',1000)";
        db.execSQL(sanphamchitiet);
        //create table hoadon
        String CREATE_TABLE_HOADON = "CREATE TABLE hoadon(" +
                "mshd TEXT UNIQUE PRIMARY KEY NOT NULL," +
                "msnv TEXT NOT NULL REFERENCES nhanvien(msnv) ON DELETE CASCADE ON UPDATE CASCADE," +
                "mskh TEXT REFERENCES khachhang(mskh) ON DELETE CASCADE ON UPDATE CASCADE," +
                "phanloaiHD INTEGER  ," +
                "ngaymua DATE  ," +
                "trangthai INTEGER)";
        db.execSQL(CREATE_TABLE_HOADON);
        //create table hoadonchitiet
        String CREATE_TABLE_HDCHITIET = "CREATE TABLE hoadonchitiet(" +
                "mshdct INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL ," +
                "mshd TEXT  NOT NULL REFERENCES hoadon(mshd) ON DELETE CASCADE ON UPDATE CASCADE," +
                "mssp TEXT  NOT NULL REFERENCES sanpham(mssp) ON DELETE CASCADE ON UPDATE CASCADE," +
                "soluong INTEGER ," +
                "dongia DOUBLE ," +
                "baohanh INTEGER," +
                "giamgia INTEGER)";
        db.execSQL(CREATE_TABLE_HDCHITIET);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }
}
