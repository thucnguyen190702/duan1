package com.example.computermanage.model;

public class GetDonGiaNhap {
    double dongia;

    public GetDonGiaNhap(double dongia) {
        this.dongia = dongia;
    }

    public GetDonGiaNhap() {
    }

    public double getDongia() {
        return dongia;
    }

    public void setDongia(double dongia) {
        this.dongia = dongia;
    }
}
